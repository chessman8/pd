import React from 'react';

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
  mobile?: boolean;
}

export function NavLink({ href, children, mobile }: NavLinkProps) {
  const baseStyles = "font-medium transition-colors duration-200";
  const mobileStyles = mobile
    ? "block px-3 py-2 text-base text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-md"
    : "text-gray-600 hover:text-gray-900";

  return (
    <a href={href} className={`${baseStyles} ${mobileStyles}`}>
      {children}
    </a>
  );
}