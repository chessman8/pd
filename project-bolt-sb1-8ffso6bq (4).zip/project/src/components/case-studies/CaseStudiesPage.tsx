import React from 'react';

const caseStudies = [
  {
    title: 'Enterprise AI Transformation',
    company: 'Tech Corp International',
    description: 'Implemented AI solutions resulting in 40% efficiency increase',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=1000',
  },
  {
    title: 'Smart Customer Service',
    company: 'Global Retail Solutions',
    description: 'Reduced response time by 60% with AI chatbots',
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=1000',
  },
];

export function CaseStudiesPage() {
  return (
    <div className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Case Studies</h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Success stories from our valued clients
          </p>
        </div>
        <div className="mt-20 grid gap-12 lg:grid-cols-2">
          {caseStudies.map((study) => (
            <div key={study.title} className="bg-white rounded-2xl shadow-xl overflow-hidden">
              <div className="h-64 w-full overflow-hidden">
                <img
                  src={study.image}
                  alt={study.title}
                  className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900">{study.title}</h3>
                <p className="mt-2 text-lg text-blue-600">{study.company}</p>
                <p className="mt-4 text-gray-500">{study.description}</p>
                <button className="mt-6 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                  Read More
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}