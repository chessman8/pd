import React from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export function ContactInfo() {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6">AI-Solutions</h3>
      <div className="space-y-4">
        <div className="flex items-start">
          <MapPin className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
          <div className="ml-3">
            <p className="text-gray-700">
              The London college, Tinkune,
              <br />
              kathmandu
            </p>
          </div>
        </div>
        
        <div className="flex items-center">
          <Phone className="h-6 w-6 text-blue-600 flex-shrink-0" />
          <p className="ml-3 text-gray-700">+977 9800000000</p>
        </div>
        
        <div className="flex items-center">
          <Mail className="h-6 w-6 text-blue-600 flex-shrink-0" />
          <p className="ml-3 text-gray-700">contact@ai-solutions.com</p>
        </div>
        
        <div className="flex items-start">
          <Clock className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
          <div className="ml-3">
            <p className="text-gray-700">
              Monday - Friday: 9:00 AM - 6:00 PM
              <br />
              Saturday: 9:00 AM - 1:00 PM
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}