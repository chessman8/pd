import React from 'react';
import { Bot, Lightbulb, HeadphonesIcon } from 'lucide-react';
import { FeatureCard } from './FeatureCard';

const features = [
  {
    title: 'AI Virtual Assistant',
    description: 'Responsive, intuitive AI to assist users with ease, providing instant support and guidance.',
    icon: Bot,
  },
  {
    title: 'Prototyping Solutions',
    description: 'Affordable and efficient tools for rapid prototyping and design iteration.',
    icon: Lightbulb,
  },
  {
    title: 'Customer Support',
    description: 'Expert support team available to guide you through every step of your journey.',
    icon: HeadphonesIcon,
  },
];

export function Features() {
  return (
    <div id="features" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            AI-Powered Solutions
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Discover our comprehensive suite of AI solutions designed to drive
            innovation and efficiency.
          </p>
        </div>

        <div className="mt-20">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <FeatureCard
                key={feature.title}
                title={feature.title}
                description={feature.description}
                Icon={feature.icon}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}