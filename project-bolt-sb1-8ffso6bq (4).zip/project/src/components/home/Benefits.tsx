import React from 'react';
import { Zap, TrendingUp, Lightbulb } from 'lucide-react';

const benefits = [
  {
    title: 'Enhanced Productivity',
    description: 'Streamline workflows and boost team efficiency with AI-powered automation.',
    icon: Zap,
  },
  {
    title: 'Accelerated Development',
    description: 'Speed up design and engineering processes with intelligent solutions.',
    icon: TrendingUp,
  },
  {
    title: 'Innovation Driver',
    description: 'Foster creativity and innovation with cutting-edge AI technologies.',
    icon: Lightbulb,
  },
];

export function Benefits() {
  return (
    <div className="bg-gray-50 py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Transform Your Business
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Experience the power of AI-driven solutions that deliver real results.
          </p>
        </div>
        <div className="mt-20">
          <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8 md:gap-y-10">
            {benefits.map((benefit) => (
              <div key={benefit.title} className="relative">
                <dt>
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                    <benefit.icon className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-gray-900">
                    {benefit.title}
                  </p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-gray-500">
                  {benefit.description}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}