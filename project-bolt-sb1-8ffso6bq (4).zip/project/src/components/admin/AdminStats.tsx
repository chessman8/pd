import React from 'react';
import { BarChart, Users, MessageSquare, Calendar } from 'lucide-react';

export function AdminStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <StatCard
        icon={Users}
        title="Total Inquiries"
        value="1,234"
        trend="+12%"
      />
      <StatCard
        icon={MessageSquare}
        title="New Messages"
        value="56"
        trend="+5%"
      />
      <StatCard
        icon={Calendar}
        title="Upcoming Events"
        value="8"
        trend="0"
      />
      <StatCard
        icon={BarChart}
        title="Conversion Rate"
        value="23%"
        trend="+2%"
      />
    </div>
  );
}

function StatCard({ icon: Icon, title, value, trend }: any) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center">
        <Icon className="h-8 w-8 text-blue-600" />
        <h2 className="ml-3 text-lg font-semibold text-gray-900">{title}</h2>
      </div>
      <p className="mt-4 text-3xl font-bold text-gray-900">{value}</p>
      <p className={`mt-2 text-sm ${trend.startsWith('+') ? 'text-green-600' : 'text-gray-500'}`}>
        {trend} from last month
      </p>
    </div>
  );
}