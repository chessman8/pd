import React from 'react';
import { BarChart, Users, MessageSquare, Calendar } from 'lucide-react';
import { AdminStats } from './AdminStats';
import { InquiriesTable } from './InquiriesTable';
import { EventsManager } from './EventsManager';
import { ArticlesManager } from './ArticlesManager';

export function Dashboard() {
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);
  const [password, setPassword] = React.useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // In production, this should be a secure authentication system
    if (password === 'admin123') {
      setIsAuthenticated(true);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <form onSubmit={handleLogin} className="bg-white p-8 rounded-lg shadow-md w-96">
          <h2 className="text-2xl font-bold mb-6">Admin Login</h2>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter password"
            className="w-full p-2 border rounded mb-4"
          />
          <button
            type="submit"
            className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700"
          >
            Login
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Admin Dashboard</h1>
        <AdminStats />
        <InquiriesTable />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
          <EventsManager />
          <ArticlesManager />
        </div>
      </div>
    </div>
  );
}