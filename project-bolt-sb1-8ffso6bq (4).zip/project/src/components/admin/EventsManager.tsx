import React from 'react';
import { Calendar } from 'lucide-react';

export function EventsManager() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center mb-4">
        <Calendar className="h-6 w-6 text-blue-600 mr-2" />
        <h2 className="text-xl font-semibold text-gray-900">Upcoming Events</h2>
      </div>
      <div className="space-y-4">
        <div className="border-l-4 border-blue-600 pl-4">
          <h3 className="font-medium text-gray-900">AI Solutions Showcase</h3>
          <p className="text-sm text-gray-500">March 25, 2024</p>
        </div>
        <div className="border-l-4 border-blue-600 pl-4">
          <h3 className="font-medium text-gray-900">Tech Innovation Summit</h3>
          <p className="text-sm text-gray-500">April 10, 2024</p>
        </div>
      </div>
    </div>
  );
}