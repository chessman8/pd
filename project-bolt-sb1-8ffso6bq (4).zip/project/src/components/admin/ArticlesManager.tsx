import React from 'react';
import { FileText } from 'lucide-react';

export function ArticlesManager() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center mb-4">
        <FileText className="h-6 w-6 text-blue-600 mr-2" />
        <h2 className="text-xl font-semibold text-gray-900">Recent Articles</h2>
      </div>
      <div className="space-y-4">
        <div className="border-b pb-4">
          <h3 className="font-medium text-gray-900">The Future of AI in Business</h3>
          <p className="text-sm text-gray-500">Published: March 15, 2024</p>
        </div>
        <div className="border-b pb-4">
          <h3 className="font-medium text-gray-900">Transforming Customer Experience</h3>
          <p className="text-sm text-gray-500">Published: March 10, 2024</p>
        </div>
      </div>
    </div>
  );
}