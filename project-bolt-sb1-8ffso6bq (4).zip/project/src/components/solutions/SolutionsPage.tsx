import React from 'react';
import { Brain, Bot, LineChart } from 'lucide-react';

const solutions = [
  {
    title: 'AI Analytics',
    description: 'Advanced analytics powered by machine learning algorithms to derive actionable insights from your data.',
    icon: Brain,
  },
  {
    title: 'Chatbot Solutions',
    description: 'Intelligent conversational AI for enhanced customer support and engagement.',
    icon: Bot,
  },
  {
    title: 'Business Intelligence',
    description: 'Data-driven decision making tools to optimize your business processes.',
    icon: LineChart,
  },
];

export function SolutionsPage() {
  return (
    <div className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Our Solutions</h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Comprehensive AI solutions tailored to your business needs
          </p>
        </div>
        <div className="mt-20 grid grid-cols-1 gap-12 lg:grid-cols-3">
          {solutions.map((solution) => (
            <div key={solution.title} className="relative p-8 bg-white rounded-2xl shadow-xl">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <span className="inline-flex items-center justify-center p-3 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg">
                  <solution.icon className="h-6 w-6 text-white" />
                </span>
              </div>
              <div className="pt-4">
                <h3 className="text-xl font-medium text-gray-900 text-center">{solution.title}</h3>
                <p className="mt-4 text-gray-500">{solution.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}