import React from 'react';
import { Star } from 'lucide-react';

interface ReviewCardProps {
  author: string;
  content: string;
  rating: number;
}

export function ReviewCard({ author, content, rating }: ReviewCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 transform transition-transform duration-300 hover:scale-105">
      <div className="flex items-center space-x-1 mb-4">
        {Array.from({ length: 5 }).map((_, index) => (
          <Star
            key={index}
            className={`h-5 w-5 ${
              index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
            }`}
          />
        ))}
      </div>
      <p className="text-gray-600 mb-4">{content}</p>
      <p className="font-semibold text-gray-800">{author}</p>
    </div>
  );
}