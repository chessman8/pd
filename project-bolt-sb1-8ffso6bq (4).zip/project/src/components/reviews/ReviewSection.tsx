import React, { useState } from 'react';
import { Star } from 'lucide-react';
import { ReviewCard } from './ReviewCard';
import { RatingInput } from './RatingInput';

const reviews = [
  {
    author: 'Rupesh Karki',
    content: 'I was really impressed with AI-Solutions! Their virtual assistant made communication so easy, and the affordable prototyping solutions helped bring my ideas to life faster than I imagined. Their focus on improving the employee experience is truly commendable!',
    rating: 5,
  },
  {
    author: 'Nischal Thapa',
    content: 'AI-Solutions is a game-changer! Their software solutions are smart and easy to use. The team\'s dedication to innovation and customer satisfaction stands out. Highly recommend this company for any business looking to improve their workflow!',
    rating: 5,
  },
  {
    author: 'John Mathews',
    content: 'Their AI-powered tools saved us so much time and effort. I especially loved how their virtual assistant quickly resolved our queries. The company\'s approach is innovative, and their solutions are affordable and effective!',
    rating: 5,
  },
  {
    author: 'Harry Johnes',
    content: 'Fantastic service and great innovation! AI-Solutions helped us streamline our processes and improve employee satisfaction. The team is professional, and their unique solutions make them stand out. Five stars without a doubt!',
    rating: 5,
  },
];

export function ReviewSection() {
  const [userRating, setUserRating] = useState(0);
  const [showThankYou, setShowThankYou] = useState(false);

  const handleRatingSubmit = () => {
    if (userRating > 0) {
      setShowThankYou(true);
      setTimeout(() => {
        setShowThankYou(false);
        setUserRating(0);
      }, 3000);
    }
  };

  return (
    <div className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            What Our Clients Say
          </h2>
          <p className="mt-4 text-xl text-gray-500">
            Don't just take our word for it - hear from our satisfied clients
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {reviews.map((review) => (
            <ReviewCard key={review.author} {...review} />
          ))}
        </div>

        <div className="max-w-xl mx-auto bg-white rounded-lg shadow-lg p-8">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-6">
            Rate Your Experience
          </h3>
          <div className="flex flex-col items-center space-y-4">
            <RatingInput rating={userRating} onRatingChange={setUserRating} />
            <button
              onClick={handleRatingSubmit}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-200"
              disabled={userRating === 0}
            >
              Submit Rating
            </button>
            {showThankYou && (
              <p className="text-green-600 font-medium animate-fade-in">
                Thank you for your rating!
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}