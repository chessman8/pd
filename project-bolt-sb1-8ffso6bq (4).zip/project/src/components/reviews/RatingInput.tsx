import React from 'react';
import { Star } from 'lucide-react';

interface RatingInputProps {
  rating: number;
  onRatingChange: (rating: number) => void;
}

export function RatingInput({ rating, onRatingChange }: RatingInputProps) {
  return (
    <div className="flex items-center space-x-1">
      {Array.from({ length: 5 }).map((_, index) => (
        <button
          key={index}
          onClick={() => onRatingChange(index + 1)}
          className="focus:outline-none"
        >
          <Star
            className={`h-8 w-8 transition-colors duration-200 ${
              index < rating
                ? 'text-yellow-400 fill-current'
                : 'text-gray-300 hover:text-yellow-400'
            }`}
          />
        </button>
      ))}
    </div>
  );
}