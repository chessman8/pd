import React from 'react';
import { Bot, User } from 'lucide-react';

interface ChatMessageProps {
  type: 'user' | 'bot';
  content: string;
}

export function ChatMessage({ type, content }: ChatMessageProps) {
  const isBot = type === 'bot';
  
  return (
    <div className={`flex items-start space-x-2 ${isBot ? '' : 'flex-row-reverse space-x-reverse'}`}>
      <div className={`p-2 rounded-full ${isBot ? 'bg-blue-100' : 'bg-gray-100'}`}>
        {isBot ? <Bot size={16} /> : <User size={16} />}
      </div>
      <div
        className={`max-w-[70%] p-3 rounded-lg ${
          isBot
            ? 'bg-blue-50 text-gray-800'
            : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white'
        }`}
      >
        {content}
      </div>
    </div>
  );
}