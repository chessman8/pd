import React from 'react';
import { Navbar } from './components/navigation/Navbar';
import { Hero } from './components/home/Hero';
import { Features } from './components/home/Features';
import { Benefits } from './components/home/Benefits';
import { ReviewSection } from './components/reviews/ReviewSection';
import { SolutionsPage } from './components/solutions/SolutionsPage';
import { CaseStudiesPage } from './components/case-studies/CaseStudiesPage';
import { ContactForm } from './components/contact/ContactForm';
import { ContactInfo } from './components/contact/ContactInfo';
import { ChatBot } from './components/chat/ChatBot';
import { NewsletterSignup } from './components/newsletter/NewsletterSignup';
import { Dashboard } from './components/admin/Dashboard';

function App() {
  const isAdminRoute = window.location.pathname === '/admin';

  if (isAdminRoute) {
    return <Dashboard />;
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <Hero />
        <Features />
        <Benefits />
        <SolutionsPage />
        <CaseStudiesPage />
        <ReviewSection />
        <NewsletterSignup />
        <div id="contact" className="py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Contact Us</h2>
              <p className="mt-4 text-lg text-gray-500">
                Get in touch with our team to learn more about our solutions
              </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <ContactForm />
              </div>
              <div>
                <ContactInfo />
              </div>
            </div>
          </div>
        </div>
      </main>
      <ChatBot />
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>&copy; 2024 AI-Solutions. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;