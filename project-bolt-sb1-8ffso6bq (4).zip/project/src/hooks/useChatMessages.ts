import { useState, useCallback } from 'react';

interface Message {
  type: 'user' | 'bot';
  content: string;
}

const getBotResponse = (message: string): string => {
  const responses = {
    greeting: ["Hello! How can I help you today?", "Hi there! What can I do for you?"],
    about: ["We're AI-Solutions, specializing in AI-powered innovation for digital workplaces.", "We provide cutting-edge AI solutions to transform businesses."],
    services: ["We offer AI Virtual Assistants, Prototyping Solutions, and Expert Customer Support.", "Our services include AI-powered tools and solutions for business automation."],
    contact: ["You can reach us through our contact form or email us at contact@ai-solutions.com", "Feel free to fill out our contact form, and we'll get back to you shortly."],
    default: ["For more details contact our customer service. Thank you."],
  };

  const lowercaseMsg = message.toLowerCase();
  
  if (lowercaseMsg.includes('hello') || lowercaseMsg.includes('hi')) {
    return responses.greeting[Math.floor(Math.random() * responses.greeting.length)];
  } else if (lowercaseMsg.includes('about')) {
    return responses.about[Math.floor(Math.random() * responses.about.length)];
  } else if (lowercaseMsg.includes('service')) {
    return responses.services[Math.floor(Math.random() * responses.services.length)];
  } else if (lowercaseMsg.includes('contact')) {
    return responses.contact[Math.floor(Math.random() * responses.contact.length)];
  }
  
  return responses.default[0];
};

export function useChatMessages() {
  const [messages, setMessages] = useState<Message[]>([
    { type: 'bot', content: 'Hello! How can I assist you today?' },
  ]);

  const sendMessage = useCallback((content: string) => {
    setMessages(prev => [
      ...prev,
      { type: 'user', content },
      { type: 'bot', content: getBotResponse(content) },
    ]);
  }, []);

  return { messages, sendMessage };
}